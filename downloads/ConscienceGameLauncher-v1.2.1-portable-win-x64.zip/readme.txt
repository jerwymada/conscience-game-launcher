Conscience Game Launcher

Run ConscienceGameLauncher.exe from the distribution root.

The HTML interface, Material Symbols icons, decorative images and Inter font
are compiled into the application.

Requirements:
- .NET 10 Desktop Runtime (x64)
- Microsoft Edge WebView2 Runtime

Install the official Microsoft runtimes before starting the portable edition:

1. .NET 10 Desktop Runtime (x64)
   https://aka.ms/dotnet/10.0/windowsdesktop-runtime-win-x64.exe

2. Microsoft Edge WebView2 Evergreen Runtime
   https://go.microsoft.com/fwlink/p/?LinkId=2124703

These links download the official Microsoft installers. The portable archive
does not bundle either runtime, which keeps it small.

The installed edition stores user data in %LocalAppData%\ConscienceGameLauncher.
The portable edition keeps mutable data under Data beside the executable.
Existing data from %LocalAppData%\GameModeSwitcher is migrated automatically.

The main window, games and mod tools run with standard user rights. Windows
requests administrator consent only when the restricted helper performs a
protected firewall, hosts, network-adapter or service operation. Refusing that
UAC request safely blocks the affected session step.
One accepted UAC request is reused for the protected operations in that session.
Windows startup and minimize-to-notification-area are disabled by default.

The installer does not start the application from its elevated process. Launch
it afterward with the desktop or Start menu shortcut. An application instance
started explicitly as administrator displays one warning and exits without
creating another instance.

If an official game launcher is already running as administrator, close it and
restart it normally before launching a game. Solo mod buttons become available
only after the game process has been detected.
